#TODO

* Change how POST parameters are passed to better match GET (use args variable).
* Need PUT example. How?
* Rename args.lua to get.lua, so it matches post.lua convention.
* How can I test the whole JSON post thing?
